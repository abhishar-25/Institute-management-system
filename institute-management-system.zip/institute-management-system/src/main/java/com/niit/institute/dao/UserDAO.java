package com.niit.institute.dao;

import com.niit.institute.model.User;

public interface UserDAO {
	

	public User checkUser(User theUser);

}
